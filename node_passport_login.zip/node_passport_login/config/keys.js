dbPassword = 'mongodb+srv://arunsinghsnd:pRlnS5m4oXOA87XA@cluster0.uzjll.mongodb.net/<dbname>?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
